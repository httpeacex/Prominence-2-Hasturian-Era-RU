#!/usr/bin/env python3
"""
Сборка assets/prominent/lang/ru_ru.json.

Пять строк с кастомными глифами (символы приватной области Unicode)
переводятся хирургически: заменяется только английское словосочетание,
всё остальное — §-коды и глифы — копируется из исходника байт в байт.
"""
import json, os

SRC = 'extract/prominent/en_us.json'
DST = 'out/resourcepack/assets/prominent/lang/ru_ru.json'

# Строки с глифами: заменяем только английский хвост, глиф не трогаем
PHRASE = {
    'item.prominent.ability.ekavar.arcane_power': ('Arcane Power', 'Тайная сила'),
    'item.prominent.ability.ekavar.fire_power':   ('Fire Power',   'Сила огня'),
    'item.prominent.ability.ekavar.frost_power':  ('Frost Power',  'Сила льда'),
    'item.prominent.ability.ekavar.holy_power':   ('Holy Power',   'Сила света'),
    'item.prominent.ability.ekavar.astral_power': ('Astral Power', 'Астральная сила'),
    'item.prominent.ability.ghaj.feed_me.damage': (
        'Deal %d', 'Нанесите %d'),
}
# второй проход по той же строке (у ghaj два фрагмента вокруг глифа)
PHRASE2 = {
    'item.prominent.ability.ghaj.feed_me.damage': (
        'corruption damage to your target, then',
        'урона порчей вашей цели, затем'),
}

T = {
    # ── вкладки и иконка ──────────────────────────────────────────────
    'itemGroup.prominent.tab': 'Prominence: особый контент',
    'itemGroup.prominent.mythic': 'Prominence: мифические боссы',
    'item.prominent.icon': 'Prominent',

    # ── музыкальные пластинки ─────────────────────────────────────────
    'item.prominent.music_disc_coniferus_forest': 'Музыкальная пластинка',
    'item.prominent.music_disc_coniferus_forest.desc':
        'Orangery — Coniferus Forest (тема главного меню)',
    'item.prominent.music_disc_festivities': 'Музыкальная пластинка',
    'item.prominent.music_disc_festivities.desc':
        'Sideralis Music — Prominent Festivities (оригинальный саундтрек)',

    # ── базовые предметы ──────────────────────────────────────────────
    'item.prominent.knowledge_scroll': 'Свиток Знаний',
    'item.prominent.molten_core': 'Расплавленное Ядро',
    'item.prominent.cinderstone_trophy': 'Трофей из Пепельного Камня',
    'item.prominent.molten_remnant': 'Расплавленный Осколок',
    'item.prominent.infused_molten_remnant': 'Наполненный Расплавленный Осколок',

    # ── Громогнев ─────────────────────────────────────────────────────
    'item.prominent.thunderwrath': 'Громогнев, Лавовый Шторм',
    'item.prominent.ability.thunderwrath.artifact': 'Артефакт Тлеющей Бури',
    'item.prominent.ability.thunderwrath.serkonid_heritage': 'Наследие Серконидов',
    'item.prominent.ability.thunderwrath.damage_message':
        'Атаки с вероятностью 25%% бьют повторно, нанося %d урона молнией.',
    'item.prominent.ability.thunderwrath.warriors_devotion':
        'Преданность Воина повышает эту вероятность до 35%%.',

    # ── Супернова ─────────────────────────────────────────────────────
    'item.prominent.supernova': 'Супернова, Смерть Звезды',
    'item.prominent.ability.supernova.artifact': 'Космический Артефакт',
    'item.prominent.ability.supernova.astral_burst': 'Астральный Взрыв',
    'item.prominent.ability.supernova.astral_burst.desc1':
        'Стягивает всю энергию Суперновы в одну точку,',
    'item.prominent.ability.supernova.astral_burst.desc2':
        'которая взрывается смертоносной новой, разя всех врагов вокруг.',
    'item.prominent.ability.supernova.arcane_projection': 'Тайная Проекция',
    'item.prominent.ability.supernova.arcane_projection.desc1':
        'Сосредоточьтесь на одной цели, затем обрушьте на неё мощный',
    'item.prominent.ability.supernova.arcane_projection.desc2':
        'звуковой удар, наносящий физический и тайный урон.',
    'item.prominent.ability.supernova.frost_projection': 'Ледяная Проекция',
    'item.prominent.ability.supernova.frost_projection.desc1':
        'Направляет град сосулек в ближайшую цель. Если цель погибает,',
    'item.prominent.ability.supernova.frost_projection.desc2':
        'поток продолжается на следующую ближайшую цель.',
    'item.prominent.ability.supernova.fire_projection': 'Огненная Проекция',
    'item.prominent.ability.supernova.fire_projection.desc1':
        'Телепортирует вас за спину врага и наносит пылающий удар,',
    'item.prominent.ability.supernova.fire_projection.desc2':
        'нанося физический и огненный урон. Можно поддерживать.',
    'item.prominent.ability.supernova.astral_echoing': 'Астральное Эхо',
    'item.prominent.ability.supernova.astral_echoing.desc':
        'Ваши удары могут откликаться дополнительным уроном стихий.',

    # ── Ярость Тысячи Кулаков ─────────────────────────────────────────
    'item.prominent.fury_of_a_thousand_fists': 'Ярость Тысячи Кулаков',
    'item.prominent.ability.fury_of_a_thousand_fists.artifact': 'Артефакт Пламени Душ',
    'item.prominent.ability.fury_of_a_thousand_fists.enraging': 'Разъярение',
    'item.prominent.ability.fury_of_a_thousand_fists.enraging.desc1':
        'Разъяритесь, наполнив кулаки скоростью атаки +500%',
    'item.prominent.ability.fury_of_a_thousand_fists.enraging.desc2':
        'на 2 секунды. В ярости атаки могут наносить дополнительный урон пламенем душ.',
    'item.prominent.ability.fury_of_a_thousand_fists.requirement':
        'Требует Кулак Ярости во второй руке.',

    # ── Ледяная Скорбь ────────────────────────────────────────────────
    'item.prominent.frostmourne': 'Ледяная Скорбь, Клинок Павшего Короля',
    'item.prominent.ability.frostmourne.artifact': 'Рунический Артефакт',
    'item.prominent.ability.frostmourne.curse_of_agony': 'Проклятие Агонии',
    'item.prominent.ability.frostmourne.curse_of_agony.desc1':
        'Тот, кто владеет Ледяной Скорбью, станет новым Королём-личом.',
    'item.prominent.ability.frostmourne.curse_of_agony.desc2':
        'Способности Рыцаря Смерти наносят больше урона.',
    'item.prominent.ability.frostmourne.casting_info':
        'Использует способности Рыцаря Смерти из снаряжённой книги умений.',

    # ── А'зар ─────────────────────────────────────────────────────────
    'item.prominent.azhar': "А'зар, Коса Проклятых",
    'item.prominent.ability.azhar.artifact': 'Артефакт Пламени Душ',
    'item.prominent.ability.azhar.soul_absorption': 'Поглощение Душ',
    'item.prominent.ability.azhar.soul_absorption.desc1':
        'Поглощает все Расколотые души, исцеляя вас на 10% максимального',
    'item.prominent.ability.azhar.soul_absorption.desc2':
        'здоровья за каждый заряд.',
    'item.prominent.ability.azhar.breath_of_azhar': "Дыхание А'зара",
    'item.prominent.ability.azhar.breath_of_azhar.desc1':
        "Высвобождает дыхание А'зара, нанося высокий урон пламенем душ",
    'item.prominent.ability.azhar.breath_of_azhar.desc2':
        'в широком конусе. Без заряда Расколотой души вы получаете непрерывный урон, пока дыхание активно.',
    'item.prominent.ability.azhar.broken_souls': 'Расколотые Души',
    'item.prominent.ability.azhar.broken_souls.desc1':
        'Расколотые души длятся 5 секунд, новые заряды не обновляют длительность.',
    'item.prominent.ability.azhar.broken_souls.desc2':
        'Когда души истекают, вы исцеляетесь на 10% максимального здоровья.',
    'item.prominent.ability.azhar.broken_souls.subdesc1':
        'Атаки создают Расколотую душу, но отнимают 10% вашего здоровья.',
    'item.prominent.ability.azhar.broken_souls.subdesc2':
        'Убийство врага создаёт Расколотую душу без урона по вам.',

    # ── Фир'алат ──────────────────────────────────────────────────────
    'item.prominent.fyralath': "Фир'алат, Опалённая Агония",
    'item.prominent.ability.fyralath.artifact': 'Артефакт Пламени Душ',
    'item.prominent.ability.fyralath.greater_scorch': 'Великое Опаление',
    'item.prominent.ability.fyralath.greater_scorch.desc1':
        'Поджигает цель и даёт вам сопротивление урону',
    'item.prominent.ability.fyralath.greater_scorch.desc2':
        'на 4 секунды. Атаки могут продлить длительность.',
    'item.prominent.ability.fyralath.greater_laceration': 'Великое Рассечение',
    'item.prominent.ability.fyralath.greater_laceration.desc1':
        "Быстрые взмахи Фир'алата раскаляют воздух и бросают в цель",
    'item.prominent.ability.fyralath.greater_laceration.desc2':
        'пылающие снаряды, подобные клинкам.',
    'item.prominent.ability.fyralath.greater_meteor': 'Великий Метеор',
    'item.prominent.ability.fyralath.greater_meteor.desc1':
        'Обрушивает на цель метеоритный дождь, нанося огненный',
    'item.prominent.ability.fyralath.greater_meteor.desc2':
        'урон всем врагам поблизости.',
    'item.prominent.ability.fyralath.fiery_core': 'Огненное Ядро',
    'item.prominent.ability.fyralath.fiery_core.desc1':
        "Фир'алат способен вызывать улучшенные огненные заклинания:",
    'item.prominent.ability.fyralath.fiery_core.desc2':
        'мгновенное чтение, больше урона и усиленные эффекты.',

    # ── Экавар ────────────────────────────────────────────────────────
    'item.prominent.ekavar_staff': 'Экавар, Великий Посох Пепельного Камня',
    'item.prominent.ekavar_staff.phase.1': "Аль На'ир, Яркая Звезда",
    'item.prominent.ekavar_staff.phase.2': 'Адассиль, Опалённое Древо',
    'item.prominent.ekavar_staff.phase.3': "Каз'эль, Ледяная Судьба",
    'item.prominent.ekavar_staff.phase.4': "Ад'анель, Тайна Айна",
    'item.prominent.ekavar_staff.phase.5': 'Сингулярность, Возрождение Звезды',
    'item.prominent.ability.ekavar.artifact': 'Артефакт Пепельного Камня',
    'item.prominent.ability.ekavar.cinderstone_core': 'Ядро Пепельного Камня',
    'item.prominent.ability.ekavar.cinderstone_core.desc1':
        'Этот посох способен обратиться в нечто большее, если наполнить его силой.',
    'item.prominent.ability.ekavar.cinderstone_core.desc2':
        'Развивается через Древо улучшений.',
    'item.prominent.ability.ekavar.arcane_infusion': 'Тайное Наполнение',
    'item.prominent.ability.ekavar.arcane_infusion.desc':
        "Посох развился, впитав первозданную Тайную силу. Теперь он известен как Аль На'ир, Яркая Звезда.",
    'item.prominent.ability.ekavar.fire_infusion': 'Огненное Наполнение',
    'item.prominent.ability.ekavar.fire_infusion.desc':
        'Посох развился, впитав первозданную силу Огня. Теперь он известен как Адассиль, Опалённое Древо.',
    'item.prominent.ability.ekavar.frost_infusion': 'Ледяное Наполнение',
    'item.prominent.ability.ekavar.frost_infusion.desc':
        "Посох развился, впитав первозданную силу Льда. Теперь он известен как Каз'эль, Ледяная Судьба.",
    'item.prominent.ability.ekavar.holy_infusion': 'Святое Наполнение',
    'item.prominent.ability.ekavar.holy_infusion.desc':
        "Посох развился, впитав первозданную силу Света. Теперь он известен как Ад'анель, Тайна Айна.",
    'item.prominent.ability.ekavar.astral_infusion': 'Астральное Наполнение',
    'item.prominent.ability.ekavar.astral_infusion.desc':
        'Посох развился, впитав первозданные астральные силы. Теперь он известен как Сингулярность, Возрождение Звезды.',
    'item.prominent.ability.ekavar.casting_info':
        'Использует Тайные, Огненные, Ледяные и Святые способности из снаряжённой Книги заклинаний.',
    'item.prominent.ekavar.phase.0': 'Ядро Пепельного Камня',
    'item.prominent.ekavar.phase.1': 'Тайное Наполнение',
    'item.prominent.ekavar.phase.2': 'Огненное Наполнение',
    'item.prominent.ekavar.phase.3': 'Ледяное Наполнение',
    'item.prominent.ekavar.phase.4': 'Святое Наполнение',
    'item.prominent.ekavar.phase.5': 'Астральное Наполнение',

    # ── Орион ─────────────────────────────────────────────────────────
    'item.prominent.orion': 'Орион, Охотник за Звёздами',
    'item.prominent.ability.orion.artifact': 'Космический Артефакт',
    'item.prominent.ability.orion.cosmic_influence': 'Космическое Влияние',
    'item.prominent.ability.orion.cosmic_influence.desc':
        'Стрелы наполняются космической силой Ориона, их скорость возрастает на 25%',
    'item.prominent.ability.orion.pledge_to_stars': 'Обет Звёздам',
    'item.prominent.ability.orion.pledge_to_stars.desc':
        'Дайте обет звезде через Древо улучшений Ориона, открыв новые эффекты.',
    'item.prominent.ability.orion.algjebbah_gift': 'Дар Альджеббаха',
    'item.prominent.ability.orion.algjebbah_gift.desc':
        'Исцеляет вас на 5% максимального здоровья при использовании способности из любой лучной книги заклинаний.',
    'item.prominent.ability.orion.mintaka_gift': 'Дар Минтаки',
    'item.prominent.ability.orion.mintaka_gift.desc':
        'Увеличивает урон ваших способностей из книги заклинаний «Ужас Минтаки».',
    'item.prominent.ability.orion.alnilam_gift': 'Дар Альнилама',
    'item.prominent.ability.orion.alnilam_gift.desc':
        'Увеличивает урон ваших способностей из книги заклинаний «Взор Альнилама».',
    'item.prominent.ability.orion.alnitak_gift': 'Дар Альнитака',
    'item.prominent.ability.orion.alnitak_gift.desc':
        'Увеличивает урон ваших способностей из книги заклинаний «Мощь Альнитака».',
    'item.prominent.ability.orion.pledge_to_nebulae': 'Обет Туманностям',
    'item.prominent.ability.orion.pledge_to_nebulae.desc':
        'Дайте обет туманности через Древо улучшений Ориона, открыв новые эффекты.',
    'item.prominent.ability.orion.horsehead_gift': 'Мощь Туманности Конская Голова',
    'item.prominent.ability.orion.horsehead_gift.desc':
        'Орион и способности лука наносят +20% урона, пока вы верхом на Коне или мифическом Кошмаре.',
    'item.prominent.ability.orion.strength_of_nebula': 'Сила Туманности Ориона',
    'item.prominent.ability.orion.strength_of_nebula.desc':
        'Ваша связь с Орионом крепнет: скорость полёта стрел +10%, но скорость натяжения −10%.',
    'item.prominent.ability.orion.casper_ghost': 'Каспер, Добрый Призрак',
    'item.prominent.ability.orion.casper_ghost.desc':
        'Пассивная Зона Концентрации теперь срабатывает и от третьей способности любой лучной книги заклинаний.',

    # ── Ваазкар ───────────────────────────────────────────────────────
    'item.prominent.vaazkar': 'Ваазкар, Защитник Расплавленного Города',
    'item.prominent.ability.vaazkar.artifact': 'Артефакт Пепельного Камня',
    'item.prominent.ability.vaazkar.wall_of_flames': 'Стена Пламени',
    'item.prominent.ability.vaazkar.wall_of_flames.desc1':
        'После 3 секунд защиты Ваазкаром вас окружает пламя,',
    'item.prominent.ability.vaazkar.wall_of_flames.desc2':
        'нанося врагам поблизости огненный урон в 3% вашего максимального здоровья в секунду.',
    'item.prominent.ability.vaazkar.wall_of_flames.desc3':
        'Длится 10 секунд, затем 15 секунд перезарядки.',
    'item.prominent.ability.vaazkar.instant_flames': 'Мгновенное Пламя',
    'item.prominent.ability.vaazkar.instant_flames.desc1':
        'Сразу при защите Ваазкаром вас окружает пламя, нанося врагам',
    'item.prominent.ability.vaazkar.instant_flames.desc2':
        'поблизости огненный урон в 3% вашего максимального здоровья в секунду.',
    'item.prominent.ability.vaazkar.instant_flames.desc3':
        'Каждый полученный от него урон вызывает у врагов провокацию.',
    'item.prominent.ability.vaazkar.instant_flames.desc4':
        'Длится до 10 секунд, затем 10 секунд перезарядки.',
    'item.prominent.ability.vaazkar.protective_flames': 'Защитное Пламя',
    'item.prominent.ability.vaazkar.protective_flames.desc1':
        'После 3 секунд защиты Ваазкаром вас окружает пламя,',
    'item.prominent.ability.vaazkar.protective_flames.desc2':
        'исцеляя игроков поблизости на 3% вашего максимального здоровья каждые 2 секунды.',
    'item.prominent.ability.vaazkar.protective_flames.desc3':
        'Длится до 10 секунд, затем 15 секунд перезарядки.',
    'item.prominent.ability.vaazkar.firestorm': 'Огненный Шторм',
    'item.prominent.ability.vaazkar.firestorm.desc1':
        'После 3 секунд защиты Ваазкаром вас окружает пламя,',
    'item.prominent.ability.vaazkar.firestorm.desc2':
        'нанося врагам поблизости огненный урон в 5% вашего максимального здоровья в секунду.',
    'item.prominent.ability.vaazkar.firestorm.desc3':
        'Длится до 10 секунд, затем 15 секунд перезарядки.',

    # ── Гх'адж ────────────────────────────────────────────────────────
    'item.prominent.ghaj': "Гх'адж, Живой Клинок",
    'item.prominent.ability.ghaj.artifact': 'Артефакт Порчи',
    'item.prominent.ability.ghaj.power_drain': 'Вытягивание Силы',
    'item.prominent.ability.ghaj.power_drain.desc1':
        'Атаки дают заряд скорости, до 5 зарядов. При пяти',
    'item.prominent.ability.ghaj.power_drain.desc2':
        "зарядах ваша сила уходит на корм Гх'аджу.",
    'item.prominent.ability.ghaj.feed_me': 'Накорми меня!',
    'item.prominent.ability.ghaj.feed_me.desc1':
        'получите заряд Покрова Пустоты, повышающий скорость атаки',
    'item.prominent.ability.ghaj.feed_me.desc2':
        'и снижающий получаемый урон на 10%, до 5 зарядов.',
    'item.prominent.ability.ghaj.dagger_mastery': 'Наполнение Кинжала',
    'item.prominent.ability.ghaj.dagger_mastery.desc1':
        "Гх'адж наполняет кинжал в вашей второй руке, открывая новую",
    'item.prominent.ability.ghaj.dagger_mastery.desc2':
        'серию из 6 атак, наносящих на 50% больше урона.',
    'dialogue.ghaj.whisper': "Гх'адж шепчет вам: ",
    'dialogue.ghaj.1': 'Ты мой. Накорми меня, дай мне силу',
    'dialogue.ghaj.2': 'Без меня ты ничто, ты слаб',
    'dialogue.ghaj.3': 'Убей их всех, устрой мне пиршество',
    'dialogue.ghaj.4': "Отнеси меня к Н'уку",
    'dialogue.ghaj.5': 'Как ты вообще ещё жив? Без меня ты так хрупок...',
    'dialogue.ghaj.6': 'Прими порчу, присоединись к нам',
    'dialogue.ghaj.7': 'Впусти меня в свой разум, дай мне власть',
    'dialogue.ghaj.8': 'Вместе мы совершили бы великое, только впусти меня',
    'dialogue.ghaj.9': 'Не слушай его, слушай меня. Только я могу тебя спасти',

    # ── Аш'эдар ───────────────────────────────────────────────────────
    'item.prominent.ashedar': "Аш'эдар, Космические Близнецы",
    'item.prominent.ash': 'Аш, Осколок Солнца',
    'item.prominent.edar': 'Эдар, Полутень',
    'item.prominent.ashedar_essence': "Эссенция Аш'эдара, Космических Близнецов",
    'item.prominent.ability.ashedar.artifact.sunfire': 'Артефакт Солнечного Пламени',
    'item.prominent.ability.ashedar.artifact.arcane': 'Тайный Артефакт',
    'item.prominent.ability.ashedar.sunstrike': 'Солнечный Удар',
    'item.prominent.ability.ashedar.sunstrike.desc':
        'Собирает ударную волну чистой солнечной мощи, нанося огненный урон всем врагам во фронтальном конусе.',
    'item.prominent.ability.ashedar.sunstrike.passive1':
        'Наносит двойной урон под Солнечным Затмением.',
    'item.prominent.ability.ashedar.sunstrike.passive2':
        'Исцеляет вас на величину урона под Лунным Затмением.',
    'item.prominent.ability.ashedar.prominence': 'Протуберанец',
    'item.prominent.ability.ashedar.prominence.desc':
        'Высвобождает истинную мощь Аша, обрушивая огненный урон на большую площадь.',
    'item.prominent.ability.ashedar.prominence.passive1':
        'Поджигает и ослепляет цели под Солнечным Затмением.',
    'item.prominent.ability.ashedar.prominence.passive2':
        'Наносит двойной урон оглушённым врагам под Лунным Затмением.',
    'item.prominent.ability.ashedar.solar_eclipse': 'Солнечное Затмение',
    'item.prominent.ability.ashedar.solar_eclipse.desc':
        "Увеличивает урон Аш'эдара на 10%. Действует 10 секунд.",
    'item.prominent.ability.ashedar.darkening': 'Затемнение',
    'item.prominent.ability.ashedar.darkening.desc':
        'Раскручивает внутреннюю тайную силу Эдара, нанося тайный урон вокруг вас.',
    'item.prominent.ability.ashedar.darkening.passive1':
        'Продлевает текущее Затмение на 2 секунды.',
    'item.prominent.ability.ashedar.darkening.passive2':
        'Исцеляет вас на величину урона под Лунным Затмением.',
    'item.prominent.ability.ashedar.moonlight_nova': 'Нова Лунного Света',
    'item.prominent.ability.ashedar.moonlight_nova.desc':
        'Высвобождает мощную нову чистого лунного света, раня и оглушая всех врагов.',
    'item.prominent.ability.ashedar.moonlight_nova.passive1':
        'Наносит двойной урон под Солнечным Затмением.',
    'item.prominent.ability.ashedar.moonlight_nova.passive2':
        'Длительность оглушения увеличена под Лунным Затмением.',
    'item.prominent.ability.ashedar.lunar_eclipse': 'Лунное Затмение',
    'item.prominent.ability.ashedar.lunar_eclipse.desc':
        'Увеличивает скорость атаки и передвижения на 10%. Действует 10 секунд.',
    'item.prominent.ability.ashedar.eclipse_cooldown':
        'Солнечное и Лунное Затмения имеют общую перезарядку.',
    'item.prominent.ability.ashedar.astral_attunement': 'Астральная Настройка',
    'item.prominent.ability.ashedar.astral_attunement.desc':
        'При бою двумя клинками-близнецами ближние атаки наносят двойной урон. Доступные заклинания зависят от того, какой клинок в основной руке.',

    # ── Апофис и Апокалипсис ──────────────────────────────────────────
    'item.prominent.apophis': 'Апофис, Божественная Рука',
    'item.prominent.ability.apophis.artifact': 'Святой Артефакт',
    'item.prominent.ability.apophis.smite': 'Божественная Кара',
    'item.prominent.ability.apophis.smite.desc1':
        'Карает врагов перед вами по площади, нанося высокий физический',
    'item.prominent.ability.apophis.smite.desc2':
        'и святой урон, причём по нежити — усиленный.',
    'item.prominent.apocalypse': 'Апокалипсис, Рука Смерти',
    'item.prominent.ability.apocalypse.artifact': 'Вечный Артефакт Смерти',
    'item.prominent.ability.apocalypse.lore':
        'Оружие, рождённое Вечностью, покорится лишь Смерти.',

    # ── иллюзии артефактов ────────────────────────────────────────────
    'item.prominent.illusion_of_thunderwrath': 'Иллюзия Громогнева',
    'item.prominent.illusion_of_supernova': 'Иллюзия Суперновы',
    'item.prominent.illusion_of_fury_of_a_thousand_fists': 'Иллюзия Ярости Тысячи Кулаков',
    'item.prominent.illusion_of_frostmourne': 'Иллюзия Ледяной Скорби',
    'item.prominent.illusion_of_azhar': "Иллюзия А'зара",
    'item.prominent.illusion_of_fyralath': "Иллюзия Фир'алата",
    'item.prominent.illusion_of_ekavar_staff': 'Иллюзия Экавара',
    'item.prominent.illusion_of_ash': 'Иллюзия Аша',
    'item.prominent.illusion_of_edar': 'Иллюзия Эдара',
    'item.prominent.illusion_of_orion': 'Иллюзия Ориона',
    'item.prominent.illusion_of_vaazkar': 'Иллюзия Ваазкара',
    'item.prominent.illusion_of_ghaj': "Иллюзия Гх'аджа",
    'item.prominent.illusion_of_apophis': 'Иллюзия Апофиса',

    # ── заклинания ────────────────────────────────────────────────────
    'spell.prominent.supernova.name': 'Астральный Взрыв',
    'spell.prominent.supernova.description':
        'Стягивает всю энергию Суперновы в одну точку, которая взрывается смертоносной новой, нанося тайный урон всем врагам поблизости.',
    'spell.prominent.rage.name': 'Разъяриться',
    'spell.prominent.rage.description':
        'Высвобождает внутреннюю ярость, повышая скорость атаки на 500% на короткое время. Требует Кулак Ярости и кулак тысячи яростей.',

    # ── эссенции и материалы ──────────────────────────────────────────
    'item.prominent.demon_essence': 'Демоническая Эссенция',
    'item.prominent.glory_essence': 'Эссенция Славы',
    'item.prominent.wrath_essence': 'Эссенция Гнева',
    'item.prominent.cosmic_essence': 'Космическая Эссенция',
    'item.prominent.encased_remnant': 'Заключённый Осколок',
    'item.prominent.beacon_of_hope': 'Маяк Надежды',
    'item.prominent.broken_beacon_of_hope': 'Разбитый Маяк Надежды',
    'item.prominent.empty_vessel': 'Сосуд из Пепельного Камня',
    'item.prominent.void_hourglass': 'Пустотные Песочные Часы',
    'item.prominent.lesser_mythical_essence': 'Малая Мифическая Эссенция',
    'item.prominent.greater_mythical_essence': 'Большая Мифическая Эссенция',

    # ── эффекты ───────────────────────────────────────────────────────
    'effect.prominent.mythic': 'Мифический',
    'effect.prominent.obliterated_agony': 'Стёртая Агония',
    'effect.prominent.remorseless_winter': 'Беспощадная Зима',
    'effect.prominent.agonizing_breath': 'Дыхание Агонии',
    'effect.prominent.broken_soul': 'Расколотая душа',
    'effect.prominent.soul_absorption': 'Поглощение душ',
    'effect.prominent.solar_eclipse': 'Солнечное Затмение',
    'effect.prominent.lunar_eclipse': 'Лунное Затмение',
    'effect.prominent.darkening': 'Затемнение',
    'effect.prominent.sunstrike': 'Солнечный Удар',
    'effect.prominent.moonlight_nova': 'Выброс Лунного Света',
    'effect.prominent.prominence': 'Выброс Протуберанца',
    'effect.prominent.oath_healing': 'Обет Исцеления',
    'effect.prominent.faceless_gift': 'Дар Безликого',
    'effect.prominent.combat': 'В бою',
    'effect.prominent.cooling_flames': 'Остывающее Пламя',

    # ── Бабушкина Сковорода ───────────────────────────────────────────
    'item.prominent.skillet': 'Бабушкина Сковорода',
    'item.prominent.ability.skillet.artifact': 'Бабушкин Артефакт',
    'item.prominent.ability.skillet.lore':
        '«С виду обычная сковорода, но на ней готовили лучшие блюда.»',
    'item.prominent.ability.skillet.granny_wrath': 'Бабушкин Гнев',
    'item.prominent.ability.skillet.granny_wrath.desc':
        'Атаки поджигают цель на 5 секунд и восполняют 1 единицу сытости.',

    # ── характеристики ────────────────────────────────────────────────
    'attribute.prominent.mythic_level': 'Мифический уровень',
    'attribute.prominent.artifact_damage': 'Урон артефакта',
    'attribute.prominent.titan_damage': 'Урон Хвата титана',
    'attribute.prominent.artifact_phase': 'Фаза артефакта',
    'block.prominent.volcanic_cinderstone': 'Вулканический Пепельный Камень',
    'item.prominent.health_flask.tooltip':
        'Восстанавливает 10% максимального здоровья и даёт Регенерацию IV на 5 секунд.',
    'item.prominent.health_flask.cooldown': ' Перезарядка 2 секунды',

    # ── статистика ────────────────────────────────────────────────────
    'stat.prominent.mythic_reforges': 'Мифических перековок',
    'stat.prominent.hck_ashedar': "Мифических испытаний пройдено с Аш'эдаром",
    'stat.prominent.hck_ekavar': 'Мифических испытаний пройдено с Экаваром',
    'stat.prominent.hck_orion': 'Мифических испытаний пройдено с Орионом',
    'stat.prominent.hck_thunderwrath': 'Мифических испытаний пройдено с Громогневом',
    'stat.prominent.hck_supernova': 'Мифических испытаний пройдено с Суперновой',
    'stat.prominent.hck_fury_of_a_thousand_fists':
        'Мифических испытаний пройдено с Яростью Тысячи Кулаков',
    'stat.prominent.hck_frostmourne': 'Мифических испытаний пройдено с Ледяной Скорбью',
    'stat.prominent.hck_azhar': "Мифических испытаний пройдено с А'заром",
    'stat.prominent.hck_fyralath': "Мифических испытаний пройдено с Фир'алатом",
    'stat.prominent.hck_ghaj': "Мифических испытаний пройдено с Гх'аджем",

    # ── трансмогрификация ─────────────────────────────────────────────
    'item.prominent.xmog_ancient_royal_great_sword': 'Иллюзия Древнего Королевского Двуручника',
    'item.prominent.xmog_aquatic_sacred_blade': 'Иллюзия Водного Священного Клинка',
    'item.prominent.xmog_aquatic_trident': 'Иллюзия Водного Трезубца',
    'item.prominent.xmog_bloodydeath': 'Иллюзия Кровавой Смерти',
    'item.prominent.xmog_chrono_blade': 'Иллюзия Хроноклинка',
    'item.prominent.xmog_creationsplitter': 'Иллюзия Рассекателя Созидания',
    'item.prominent.xmog_cyber_scythe': 'Иллюзия Квантовой Косы',
    'item.prominent.xmog_cyber_sword': 'Иллюзия Квантового Меча',
    'item.prominent.xmog_cybernetic_dagger': 'Иллюзия Квантового Кинжала',
    'item.prominent.xmog_demonic_blade': 'Иллюзия Демонического Клинка',
    'item.prominent.xmog_divine_great_axe': 'Иллюзия Божественного Топора',
    'item.prominent.xmog_divine_justice': 'Иллюзия Божественного Правосудия',
    'item.prominent.xmog_divine_punisher': 'Иллюзия Божественного Карателя',
    'item.prominent.xmog_divine_reaper': 'Иллюзия Божественного Жнеца',
    'item.prominent.xmog_excalibur': 'Иллюзия Экскалибура',
    'item.prominent.xmog_forest_guardian_glaive': 'Иллюзия Глефы Лесного Хранителя',
    'item.prominent.xmog_jade_halberd': 'Иллюзия Нефритовой Алебарды',
    'item.prominent.xmog_molten_sword': 'Иллюзия Расплавленного Меча',
    'item.prominent.xmog_mystical_spellblade': 'Иллюзия Мистического Клинка',
    'item.prominent.xmog_pharaohs_treasure': 'Иллюзия Сокровища Фараона',
    'item.prominent.xmog_pheonix_grace': 'Иллюзия Милости Феникса',
    'item.prominent.xmog_royal_chakram': 'Иллюзия Королевского Чакрама',
    'item.prominent.xmog_ruby_blade': 'Иллюзия Рубинового Клинка',
    'item.prominent.xmog_sacred_tree_blade': 'Иллюзия Клинка Священного Древа',
    'item.prominent.xmog_sculk_cleaver': 'Иллюзия Скалкового Колуна',
    'item.prominent.xmog_sculk_scythe': 'Иллюзия Скалковой Косы',
    'item.prominent.xmog_sculk_sword': 'Иллюзия Скалкового Меча',
    'item.prominent.xmog_sentinels_will': 'Иллюзия Воли Стража',
    'item.prominent.xmog_silverine_blade': 'Иллюзия Серебристого Клинка',
    'item.prominent.xmog_soul_claws': 'Иллюзия Когтей Душ',
    'item.prominent.xmog_soul_collector': 'Иллюзия Собирателя Душ',
    'item.prominent.xmog_soul_devourer': 'Иллюзия Пожирателя Душ',
    'item.prominent.xmog_soul_edge': 'Иллюзия Клинка Душ',
    'item.prominent.xmog_stop_sign': 'Иллюзия знака «СТОП»',
    'item.prominent.xmog_sunbreak': 'Иллюзия Солнцелома',
    'item.prominent.xmog_terra_blade': 'Иллюзия Терра-Клинка',
    'item.prominent.xmog_unholy_scythe': 'Иллюзия Нечестивой Косы',
    'item.prominent.xmog_void_touched_blade': 'Иллюзия Клинка, Тронутого Пустотой',
    'item.prominent.xmog_void_touched_saber': 'Иллюзия Сабли, Тронутой Пустотой',
    'item.prominent.xmog_void_touched_scythe': 'Иллюзия Косы, Тронутой Пустотой',
    'item.prominent.xmog_pumpmourne': 'Иллюзия Тыквоскорби, Клинка Зловещей Тыквы',

    # ── Камень Пламенорождённого ──────────────────────────────────────
    'item.prominent.flameborn_stone': 'Камень Пламенорождённого',
    'item.prominent.flameborn_stone.tooltip.1':
        "Создан Вечным Существом Созидания, С'келлаком. Хранит вечную связь с Расплавленным Городом Вааз.",
    'item.prominent.flameborn_stone.tooltip.2':
        'Используйте, чтобы телепортироваться в Расплавленный Город Вааз.',
    'spell.prominent.flameborn_call.name': 'Зов Пламенорождённого',
    'spell.prominent.flameborn_call.description':
        'Используйте Камень Пламенорождённого, чтобы телепортироваться в Расплавленный Город Вааз.',
    'biome.prominent.city_of_vaaz': 'Вааз, Расплавленный Город',
    'item.scarred_night.tooltip':
        'Осколок чистой тьмы, впитавший тысячи собранных душ.',
    'item.prominent.scarred_night': 'Изувеченная Ночь',
}

src = json.load(open(SRC, encoding='utf-8'))
out = {}
missing = []

for k, v in src.items():
    if k in PHRASE:
        a, b = PHRASE[k]
        nv = v.replace(a, b)
        if k in PHRASE2:
            a2, b2 = PHRASE2[k]
            nv = nv.replace(a2, b2)
        out[k] = nv
    elif k in T:
        out[k] = T[k]
    else:
        missing.append(k)
        out[k] = v

os.makedirs(os.path.dirname(DST), exist_ok=True)
json.dump(out, open(DST, 'w', encoding='utf-8'), ensure_ascii=False, indent=4)

print(f'Ключей в исходнике: {len(src)}')
print(f'Переведено: {len(src) - len(missing)}')
print(f'Без перевода: {len(missing)}')
for k in missing:
    print('  MISS', k, repr(src[k][:70]))

# контроль спецификаторов и глифов
import re
spec = re.compile(r'%(?:\d+\$)?[sdf]|%%')
bad = 0
for k, v in out.items():
    if len(spec.findall(src[k])) != len(spec.findall(v)):
        bad += 1
        print('  СПЕЦИФИКАТОР', k, spec.findall(src[k]), spec.findall(v))
    # глифы приватной области и CJK должны сохраниться
    g1 = [c for c in src[k] if ord(c) > 0x2000]
    g2 = [c for c in v if ord(c) > 0x2000]
    if g1 and g1 != g2:
        bad += 1
        print('  ГЛИФ', k, [hex(ord(c)) for c in g1], '->', [hex(ord(c)) for c in g2])
print(f'\nОшибок спецификаторов/глифов: {bad}')
